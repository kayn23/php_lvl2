create trigger user_role
  after INSERT
  on users
  for each row
  begin
	insert into `user_role`(`user_id`,`role`) values (new.id,'user');
end;

